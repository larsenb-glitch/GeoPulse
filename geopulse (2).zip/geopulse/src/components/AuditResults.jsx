import styles from './AuditResults.module.css'

function scoreColor(s) {
  if (s >= 70) return 'var(--teal-500)'
  if (s >= 45) return '#EF9F27'
  return '#E24B4A'
}

function scoreLabel(s) {
  if (s >= 70) return 'Strong'
  if (s >= 45) return 'Moderate'
  return 'Weak'
}

export default function AuditResults({ audit, bizInfo, onReset }) {
  const maxPct = Math.max(...(audit.sources || []).map(s => s.pct), 1)

  return (
    <div className={styles.results}>
      <div className={styles.topBar}>
        <div>
          <h2 className={styles.bizName}>{bizInfo.name}</h2>
          <p className={styles.bizSub}>{bizInfo.city}{bizInfo.state ? `, ${bizInfo.state}` : ''} · {bizInfo.industry}</p>
        </div>
        <button className={styles.resetBtn} onClick={onReset}>← New audit</button>
      </div>

      {/* Score cards */}
      <div className={styles.scoreGrid}>
        <div className={styles.scoreCardPrimary}>
          <div className={styles.scoreCardLabel}>AI overall score</div>
          <div className={styles.scoreCardNumLarge}>{audit.overallScore}<span>/100</span></div>
          <div className={styles.scoreCardTag} style={{ color: scoreColor(audit.overallScore) }}>
            {scoreLabel(audit.overallScore)}
          </div>
        </div>
        {[
          { label: 'Visibility', val: audit.visibility },
          { label: 'Accuracy', val: audit.accuracy },
          { label: 'Sentiment', val: audit.sentiment },
        ].map(c => (
          <div key={c.label} className={styles.scoreCard}>
            <div className={styles.scoreCardLabel}>{c.label}</div>
            <div className={styles.scoreCardNum} style={{ color: scoreColor(c.val) }}>
              {c.val}<span>/100</span>
            </div>
            <div className={styles.scoreBar}>
              <div className={styles.scoreBarFill} style={{ width: `${c.val}%`, background: scoreColor(c.val) }} />
            </div>
          </div>
        ))}
      </div>

      {/* Insights */}
      <Section label="Key insights">
        <div className={styles.insightsCard}>
          {(audit.insights || []).map((ins, i) => (
            <div key={i} className={styles.insightRow}>
              <div className={`${styles.insightDot} ${styles['dot_' + ins.type]}`} />
              <p className={styles.insightText}>{ins.text}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Sources + Competitors */}
      <Section label="Sources & competitors">
        <div className={styles.twoCol}>
          <div className={styles.panel}>
            <h3 className={styles.panelTitle}>Where AI gets its info</h3>
            {(audit.sources || []).map((s, i) => (
              <div key={i} className={styles.sourceRow}>
                <span className={styles.sourceName}>{s.name}</span>
                <div className={styles.barTrack}>
                  <div className={styles.barFill} style={{ width: `${Math.round(s.pct / maxPct * 100)}%` }} />
                </div>
                <span className={styles.sourcePct}>{s.pct}%</span>
              </div>
            ))}
          </div>
          <div className={styles.panel}>
            <h3 className={styles.panelTitle}>Competitor mentions</h3>
            {(audit.competitors || []).map((c, i) => (
              <div key={i} className={styles.compRow}>
                <span className={styles.compName}>{c.name}</span>
                <span className={styles.compBadge}>{c.mentions}x</span>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* Playbook */}
      <Section label="Action playbook">
        <div className={styles.playbookGrid}>
          <PlaybookCell title="Quick wins" subtitle="High impact · Easy" chipClass={styles.chipGreen} items={audit.playbook?.quickWins} />
          <PlaybookCell title="Strategic investments" subtitle="High impact · More effort" chipClass={styles.chipAmber} items={audit.playbook?.strategic} />
          <PlaybookCell title="Easy extras" subtitle="Low impact · Easy" chipClass={styles.chipBlue} items={audit.playbook?.easyExtras} />
          <PlaybookCell title="Deprioritize" subtitle="Low impact · More effort" chipClass={styles.chipGray} items={audit.playbook?.deprioritize} />
        </div>
      </Section>
    </div>
  )
}

function Section({ label, children }) {
  return (
    <div style={{ marginBottom: '2rem' }}>
      <p style={{ fontFamily: 'Syne, sans-serif', fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-muted)', marginBottom: '12px' }}>
        {label}
      </p>
      {children}
    </div>
  )
}

function PlaybookCell({ title, subtitle, chipClass, items = [] }) {
  return (
    <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '1.25rem' }}>
      <p style={{ fontFamily: 'Syne, sans-serif', fontSize: '13px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '2px' }}>{title}</p>
      <p style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '12px' }}>{subtitle}</p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
        {items.map((a, i) => <span key={i} className={chipClass}>{a}</span>)}
      </div>
    </div>
  )
}
